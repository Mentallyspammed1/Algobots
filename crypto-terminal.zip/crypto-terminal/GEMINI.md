# Project Root Context

This is the GEMINI.md file in the project root. It provides general context for the entire project.

## Project Transformation Summary

- **Original State:** A Next.js application.
- **Transformation:** Converted to a client-only, static web application.
- **Reason:** User chose the "Path of Transmutation" to simplify the project architecture.
- **Key Technologies:** React, TypeScript, ES Modules, Import Maps for dependency management.
- **Current Status:** The core application structure is implemented. Placeholder components (`PriceChart.tsx`, `BalanceCard.tsx`, `PositionsCard.tsx`, `PerformanceCard.tsx`, `SettingsModal.tsx`) have been filled with basic functional implementations.
- **How to Run:**
    1. Ensure `npm install` has been run to install `http-server`.
    2. Execute `npm run start` to launch the static web server.
    3. Access the application in a web browser at `http://localhost:8000`.
