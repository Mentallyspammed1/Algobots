'use client';
import { useEffect, useRef, useState } from 'react';
import type { TradingData, BotSettings, ClosedTrade } from '@/lib/types';

const WS_URL = `ws://localhost:${process.env.NEXT_PUBLIC_WS_PORT || 8080}?token=${process.env.NEXT_PUBLIC_WS_TOKEN || ''}`;

export function useBotManager() {
  const [botState, setBotState] = useState<TradingData | null>(null);
  const [settings, setSettings] = useState<BotSettings | null>(null);
  const [history, setHistory] = useState<ClosedTrade[]>([]);
  const [connected, setConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const retries = useRef(0);

  useEffect(() => {
    function connect() {
      const ws = new WebSocket(WS_URL);
      wsRef.current = ws;

      ws.onopen = () => { setConnected(true); retries.current = 0; ws.send(JSON.stringify({ type: 'get_history' })); };
      ws.onmessage = (ev) => {
        try {
          const { type, payload } = JSON.parse(ev.data);
          if (type === 'full_state') setBotState(payload);
          if (type === 'settings_update') setSettings(payload);
          if (type === 'trade_history') setHistory(payload);
        } catch {}
      };
      ws.onclose = () => {
        setConnected(false);
        const backoff = Math.min(15000, 1000 * Math.pow(2, retries.current++)) + Math.floor(Math.random()*500);
        setTimeout(connect, backoff);
      };
      ws.onerror = () => ws.close();
    }
    connect();
    return () => wsRef.current?.close();
  }, []);

  const control = (action: 'start' | 'stop') =>
    wsRef.current?.send(JSON.stringify({ type: 'control', payload: { action } }));

  const updateSettings = (patch: Partial<BotSettings>) =>
    wsRef.current?.send(JSON.stringify({ type: 'update_settings', payload: patch }));

  const switchSymbol = (symbol: string) =>
    wsRef.current?.send(JSON.stringify({ type: 'switch_symbol', payload: { symbol } }));

  const exportCSV = () => {
    const header = 'id,symbol,side,entryPrice,exitPrice,qty,pnl,entryTime,exitTime\n';
    const rows = history.map(h => [h.id,h.symbol,h.side,h.entryPrice,h.exitPrice,h.qty,h.pnl,h.entryTime,h.exitTime].join(',')).join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'trade-history.csv'; a.click();
    URL.revokeObjectURL(url);
  };

  return { botState, settings, history, connected, control, updateSettings, switchSymbol, exportCSV };
}
