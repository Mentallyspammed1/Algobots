/* ─────────────────────────────────────────────────────────────
   src/app.tsx  –  “Home page” container for the Bybit dashboard
   ───────────────────────────────────────────────────────────── */

import React, {
  useState,
  useEffect,
  lazy,
  Suspense,
  startTransition,
} from 'react';

import { ENV } from '../.env.js';
import { BybitClient } from './lib/bybitClient.ts';
import { saveSetting, loadSetting } from './lib/storage.ts';
import Loader from './components/Loader.tsx';
import Header from './components/Header.tsx';
import OrderBook from './components/OrderBook.tsx';
import TradesTape from './components/TradesTape.tsx';
import BalanceCard from './components/BalanceCard.tsx';
import PositionsCard from './components/PositionsCard.tsx';
import TradeControls from './components/TradeControls.tsx';
import PerformanceCard from './components/PerformanceCard.tsx';

const PriceChart = lazy(() => import('./components/PriceChart.tsx'));
const SettingsModal = lazy(() => import('./components/SettingsModal.tsx'));

/* ————————————————————————————————————————————————
   Global Bybit client   (1:1 with Web-Socket connection)
   ———————————————————————————————————————————————— */
const client = new BybitClient(ENV);

/* ————————————————————————————————————————————————
   Utility: i18n lookup (tiny runtime, EN/ES scaffold)
   ———————————————————————————————————————————————— */
function t(key: string): string {
  const lang = localStorage.getItem('lang') || 'en';
  const json = document.getElementById(`i18n-${lang}`)?.textContent;
  try {
    return JSON.parse(json ?? '{}')[key] ?? key;
  } catch {
    return key;
  }
}

/* ————————————————————————————————————————————————
   Component
   ———————————————————————————————————————————————— */
export default function App() {
  /* persistent settings */
  const [symbol, setSymbol] = useState<string>(ENV.SYMBOLS[0]);
  const [dark, setDark] = useState<boolean>(true);
  const [showSettings, setShowSettings] = useState(false);

  // Load settings from storage on initial render
  useEffect(() => {
    loadSetting('symbol').then(s => { if (s) setSymbol(s); });
    loadSetting('theme').then(t => { if (t) setDark(t === 'dark'); });
  }, []);


  /* apply theme */
  useEffect(() => {
    document.body.className = dark ? 'dark' : 'light';
    saveSetting('theme', dark ? 'dark' : 'light');
  }, [dark]);

  /* hot-keys:  d – dark/light,   Ctrl+S – settings */
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'd') startTransition(() => setDark((d) => !d));
      if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        setShowSettings(true);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  /* symbol selector persists to encrypted localStorage */
  const onChangeSymbol = (s: string) => {
    startTransition(() => setSymbol(s));
    saveSetting('symbol', s);
  };

  return (
    <>
      {/* ─── top bar ─────────────────────────────────────── */}
      <Header
        client={client}
        symbol={symbol}
        dark={dark}
        toggleDark={() => setDark((d) => !d)}
      />

      {/* ─── quick-controls row ─────────────────────────── */}
      <section
        style={{
          display: 'flex',
          gap: 12,
          padding: '0 8px',
          flexWrap: 'wrap',
        }}
      >
        <select
          value={symbol}
          onChange={(e) => onChangeSymbol(e.target.value)}
          style={{ padding: 4 }}
        >
          {ENV.SYMBOLS.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
        <button onClick={() => setShowSettings(true)}>{t('settings')}</button>
      </section>

      {/* ─── main responsive grid ───────────────────────── */}
      <main
        style={{
          display: 'grid',
          gap: 8,
          padding: 8,
          alignContent: 'start',
          gridTemplateColumns: 'repeat(auto-fit,minmax(330px,1fr))',
        }}
      >
        {/* chart is heavy → lazy with skeleton */}
        <Suspense fallback={<Loader height={320} />}>
          <PriceChart client={client} symbol={symbol} />
        </Suspense>

        <OrderBook client={client} />
        <TradesTape client={client} />

        <BalanceCard client={client} />
        <PositionsCard client={client} />

        <TradeControls client={client} symbol={symbol} />
        <PerformanceCard />
      </main>

      {/* ─── settings modal (lazy) ─────────────────────── */}
      {showSettings && (
        <Suspense fallback={<Loader />}>
          <SettingsModal client={client} close={() => setShowSettings(false)} />
        </Suspense>
      )}
    </>
  );
}