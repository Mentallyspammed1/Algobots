'use client';
import { useBotManager } from '@/hooks/use-bot-manager';
import Link from 'next/link';

export default function HistoryPage() {
  const { history } = useBotManager();

  const equity = history.reduce<number[]>((acc, t, i) => {
    const prev = acc[i-1] ?? 0;
    acc.push(prev + t.pnl);
    return acc;
  }, []);

  return (
    <div style={{padding:16}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <h2>Trade History</h2>
        <Link href="/">← Back</Link>
      </div>
      <div style={{margin:'12px 0', background:'#0f1115', border:'1px solid #1c1f2a', borderRadius:8, padding:12, maxHeight:400, overflow:'auto'}}>
        <table style={{width:'100%', borderCollapse:'collapse'}}>
          <thead><tr><th>Exit Time</th><th>Symbol</th><th>Side</th><th>Entry</th><th>Exit</th><th>Qty</th><th>PnL</th></tr></thead>
          <tbody>
            {history.map(h=>( 
              <tr key={h.id}>
                <td>{new Date(h.exitTime).toLocaleString()}</td>
                <td>{h.symbol}</td>
                <td>{h.side}</td>
                <td>{h.entryPrice}</td>
                <td>{h.exitPrice}</td>
                <td>{h.qty}</td>
                <td style={{color:h.pnl>=0?'#19c37d':'#ff5252'}}>{h.pnl.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div style={{background:'#0f1115', border:'1px solid #1c1f2a', borderRadius:8, padding:12}}>
        <div style={{color:'#8aa0b4'}}>Equity Curve (cumulative PnL)</div>
        <div style={{display:'flex', gap:2, marginTop:8}}>
          {equity.map((v,i)=>( 
            <div key={i} title={String(v)} style={{height:120, width:4, background:v>=0?'#19c3d':'#ff5252', transform:`scaleY(${Math.min(1, Math.abs(v)/Math.max(1, Math.max(...equity.map(e=>Math.abs(e)||1))))})`, transformOrigin:'bottom'}} />
          ))}
        </div>
      </div>
    </div>
  );
}