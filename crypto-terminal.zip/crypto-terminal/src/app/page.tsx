'use client';
import { useBotManager } from '@/hooks/use-bot-manager';
import { DashboardHeader } from '@/components/dashboard/header';
import { MarketDataCard } from '@/components/dashboard/MarketDataCard';
import { SignalCard } from '@/components/dashboard/SignalCard';
import { AccountBalanceCard } from '@/components/dashboard/AccountBalanceCard';
import { IndicatorPanel } from '@/components/dashboard/IndicatorPanel';
import { PositionsTable } from '@/components/dashboard/PositionsTable';
import { LogViewer } from '@/components/dashboard/LogViewer';
import { TradeControls } from '@/components/dashboard/TradeControls';
import { ChartCard } from '@/components/dashboard/chart-card';

export default function Page() {
  const { botState, settings, history, connected, control, updateSettings, switchSymbol, exportCSV } = useBotManager();
  if (!botState || !settings) return <div style={{padding:24}}>Connecting…</div>;

  const watchlist = settings.watchlist || ['BTCUSDT','ETHUSDT','SOLUSDT'];

  return (
    <div>
      <DashboardHeader status={botState.status} isConnected={connected} onControl={control} settings={settings} onExport={exportCSV} />
      <main style={{display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:12, padding:12}}>
        <div style={{gridColumn:'span 4', display:'flex', gap:8, flexWrap:'wrap'}}>
          {watchlist.map(sym => (
            <button key={sym} onClick={()=>switchSymbol(sym)} style={{padding:'6px 10px', border:'1px solid #1c1f2a', background: sym===botState.market_data.symbol?'#142032':'#0f1115', color:'#bcd'}}>
              {sym}
            </button>
          ))}
        </div>

        <MarketDataCard symbol={botState.market_data.symbol} price={botState.market_data.price} />
        <SignalCard signal={botState.signal} />
        <AccountBalanceCard equity={botState.account_balance.equity} available={botState.account_balance.available_balance} />
        <TradeControls settings={settings} onUpdate={updateSettings} />

        <IndicatorPanel indicators={botState.indicators} />
        <PositionsTable positions={botState.positions} />
        <LogViewer logs={botState.logs} />

        <div style={{gridColumn:'span 4'}}>
          <ChartCard
            symbol={botState.market_data.symbol}
            klines={[[String(Date.now()), botState.market_data.price, botState.market_data.price, botState.market_data.price, botState.market_data.price, '0']]}
            lastPrice={Number(botState.market_data.price||0)}
            trades={history}
          />
        </div>
      </main>
    </div>
  );
}