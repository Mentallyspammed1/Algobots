import { Toaster } from 'react-hot-toast';

export const metadata = { title: 'Bybit Trading App Pro' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ margin:0, background:'#0b0b0d', color:'#eaeaea', fontFamily:'Inter, system-ui, sans-serif' }}>
        <Toaster position="top-right" toastOptions={{ style: { background: '#222', color: '#fff' } }} />
        {children}
      </body>
    </html>
  );
}