import * as ti from 'technicalindicators';
export const rsi  =(cl:number[],p=14)=>ti.RSI.calculate({values:cl,period:p}).pop()??0;
export const macd =(cl:number[])=>ti.MACD.calculate({values:cl,fastPeriod:12,slowPeriod:26,signalPeriod:9}).pop()?.histogram??0;
export const bb   =(cl:number[])=>ti.BollingerBands.calculate({values:cl,period:20,stdDev:2}).pop();