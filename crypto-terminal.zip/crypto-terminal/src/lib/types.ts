export type LogLevel = 'INFO' | 'ERROR' | 'WARNING' | 'DEBUG';
export type SignalValue = 'BUY' | 'SELL' | 'HOLD';
export type Side = 'Buy' | 'Sell';

export interface ClosedTrade {
  id: string; symbol: string; side: Side;
  entryPrice: number; exitPrice: number; qty: number; pnl: number;
  entryTime: string; exitTime: string;
}

export interface AccountBalance { equity: string; available_balance: string; }
export interface PositionRow { side: Side; entry_price: string; qty: string; status: 'OPEN'; pnl: string; leverage: string; }
export interface MarketData { symbol: string; price: string; }
export interface Signal { value: SignalValue; score: number; }

export interface TradingData {
  status: 'Idle' | 'Running';
  market_data: MarketData;
  account_balance: AccountBalance;
  indicators: Record<string, string>;
  signal: Signal;
  positions: PositionRow[];
  logs: { timestamp: string; level: LogLevel; message: string }[];
}

export interface BotSettings {
  symbol: string;
  timeframe: '1' | '3' | '5' | '15' | '60' | '240' | 'D';
  watchlist: string[];
  strategy: 'RSI' | 'MACD_CROSS';
  riskPercentage: number;
  rsiPeriod: number;
  rsiOverbought: number;
  rsiOversold: number;
  macdFast: number;
  macdSlow: number;
  macdSignal: number;
  armedLive: boolean;
  partialClosePct: number;
}