import { GoogleGenerativeAI } from '@google/genai';
import { ENV } from '../../.env.js';
const genai=new GoogleGenerativeAI(ENV.GOOGLE_GENAI_API_KEY);
export const explainSignal=async(ind:{[k:string]:number})=>{
  try{
    const res=await genai.generations.generate({
      model:'gemini-pro',
      prompt:`Interpret these: ${JSON.stringify(ind)} in ≈30 words.`,
      maxOutputTokens:60});
    return res.text();
  }catch{return 'AI offline';}
};