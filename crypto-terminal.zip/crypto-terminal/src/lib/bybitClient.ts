import axios,{AxiosInstance} from 'axios';
import { ENV } from '../../.env.js';
import { openDB } from 'idb';
import { throttle } from './utils.ts';

const BASE=ENV.TESTNET?'https://api-testnet.bybit.com':'https://api.bybit.com';

export class BybitClient{
  http:AxiosInstance;
  ws:WebSocket;
  latency=0;
  private hits:number[]=[];
  private bookSubs:((b:[number,number][],a:[number,number][])=>void)[]=[];
  private tradeSubs:((t:{p:number,q:number,ts:number,s:'Buy'|'Sell'})=>void)[]=[];
  dbPromise=openDB('bybit-cache',1,{upgrade(db){db.createObjectStore('klines');}});

  constructor(private env=ENV){
    /* ---------- REST ---------- */
    this.http=axios.create({baseURL:BASE+'/v5',timeout:8000});
    this.http.interceptors.request.use(cfg=>{
      const ts=Date.now().toString();
      cfg.headers!['X-BAPI-API-KEY']=env.BYBIT_API_KEY;
      cfg.headers!['X-BAPI-TIMESTAMP']=ts;
      cfg.headers!['X-BAPI-RECV-WINDOW']='5000';
      // naive signature (SHA256 of ts+key+query+body)
      const q=cfg.url?.split('?')[1]??'';
      const body=cfg.data?JSON.stringify(cfg.data):'';
      const payload=ts+env.BYBIT_API_KEY+q+body;
      const hash=crypto.subtle.digest('SHA-256',new TextEncoder().encode(payload));
      return hash.then(buf=>{
        cfg.headers!['X-BAPI-SIGN']=[...new Uint8Array(buf)].map(b=>b.toString(16).padStart(2,'0')).join('');
        return cfg;
      });
    });

    /* ---------- WS ---------- */
    const wsUrl=env.TESTNET
      ?'wss://stream-testnet.bybit.com/v5/public/linear'
      :'wss://stream.bybit.com/v5/public/linear';
    this.ws=new WebSocket(wsUrl);
    this.ws.addEventListener('open',()=>{
      this.ws.send(JSON.stringify({op:'subscribe',args:[
        `orderbook.50.${env.SYMBOLS[0]}`,
        `publicTrade.${env.SYMBOLS[0]}`,
        `tickers.${env.SYMBOLS[0]}`
      ]}));
      setInterval(()=>this.ping(),5000);
    });
    this.ws.addEventListener('message',e=>{
      const m=JSON.parse(e.data);
      if(m.topic?.startsWith('orderbook')) this.bookSubs.forEach(cb=>cb(m.data.b,m.data.a));
      if(m.topic?.startsWith('publicTrade')){
        const t=m.data[0]; this.tradeSubs.forEach(cb=>cb({p:+t.p,q:+t.v,ts:+t.T,s:t.S}));
      }
      if(m==='pong') this.latency=Date.now()-this._pingTs;
    });
  }
  private _pingTs=0;
  private ping(){this._pingTs=Date.now();this.ws.send('{"op":"ping"}');}

  /* ---------- public ---------- */
  async getTicker(sym:string){
    const {data}=await this.http.get(`/market/tickers?category=linear&symbol=${sym}`);
    return data.result.list[0];
  }
  async getKlines(sym:string,interval='1',limit=200){
    const key=`${sym}-${interval}-${limit}`;
    const db=await this.dbPromise;
    const cache=await db.get('klines',key);
    if(cache) return cache;
    const {data}=await this.http.get(`/market/kline?category=linear&symbol=${sym}&interval=${interval}&limit=${limit}`);
    await db.put('klines',data.result.list,key);
    return data.result.list;
  }

  async getBalance(){return (await this.http.get('/account/wallet-balance?accountType=UNIFIED')).data.result;}
  async getPositions(sym?:string){
    return (await this.http.get(`/position/list?category=linear${sym?`&symbol=${sym}`:''}`)).data.result.list;
  }

  /* ---------- trading + rate-monitor ---------- */
  async placeOrder(body:any){
    this.hits.push(Date.now()); this.hits=this.hits.filter(t=>Date.now()-t<60000);
    const {data}=await this.http.post('/order/create',{category:'linear',timeInForce:'GTC',...body});
    return data.result;
  }
  get rate60(){return this.hits.length;}

  /* ---------- subscriptions ---------- */
  onBook(fn:(b:[number,number][],a:[number,number][])=>void){this.bookSubs.push(fn);}
  onTrade(fn:(t:{p:number,q:number,ts:number,s:'Buy'|'Sell'})=>void){this.tradeSubs.push(fn);}
}