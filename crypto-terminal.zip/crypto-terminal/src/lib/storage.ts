import { aesEncrypt, aesDecrypt } from './utils.ts';
import { ENV } from '../../.env.js';

export const saveSetting = async (k:string,v:any)=>{
  const enc= await aesEncrypt(JSON.stringify(v),ENV.ENC_KEY);
  localStorage.setItem(k,enc);
};
export const loadSetting = (k:string)=>{
  const raw=localStorage.getItem(k);
  if(!raw) return null;
  return aesDecrypt(raw,ENV.ENC_KEY).then(t=>JSON.parse(t)).catch(()=>null);
};