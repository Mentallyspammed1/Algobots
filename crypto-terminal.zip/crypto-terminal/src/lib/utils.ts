export const throttle=<T extends(...a:any)=>any>(fn:T,ms:number)=>{
  let last=0;return(...a:any)=>{const now=Date.now();if(now-last>ms){last=now;fn(...a);}};
};

/* beep */
export const beep=()=> (document.getElementById('ding') as HTMLAudioElement).play();

/* AES-GCM store encryption */
export const aesEncrypt=async(txt:string,key:string)=>{
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const cryptoKey=await crypto.subtle.importKey('raw',new TextEncoder().encode(key),'AES-GCM',false,['encrypt']);
  const buf=await crypto.subtle.encrypt({name:'AES-GCM',iv},cryptoKey,new TextEncoder().encode(txt));
  return [...iv].join(',')+':'+btoa(String.fromCharCode(...new Uint8Array(buf)));
};
export const aesDecrypt=async(blob:string,key:string)=>{
  const [ivStr,data]=blob.split(':');
  const iv=Uint8Array.from(ivStr.split(',').map(Number));
  const cryptoKey=await crypto.subtle.importKey('raw',new TextEncoder().encode(key),'AES-GCM',false,['decrypt']);
  const buf=await crypto.subtle.decrypt({name:'AES-GCM',iv},cryptoKey,Uint8Array.from(atob(data),c=>c.charCodeAt(0)));
  return new TextDecoder().decode(buf);
};