import React,{useEffect,useState} from 'react';
import { BybitClient } from '../lib/bybitClient.ts';

export default function OrderBook({client}:{client:BybitClient}){
  const [bids,setBids]=useState<[number,number][]>([]);
  const [asks,setAsks]=useState<[number,number][]>([]);
    useEffect(()=>client.onBook((b,a)=>{setBids(b.slice(0,15));setAsks(a.slice(0,15));}),[client]);
  const max = Math.max(...asks.map(x=>x[1]),...bids.map(x=>x[1]),1);
  const Row=({p,q,red}:{p:number,q:number,red?:boolean})=>
    <div style={{display:'flex',justifyContent:'space-between',
      background:`linear-gradient(to ${red?'left':'right'},${red?'#f44336':'#4caf50'}30 ${(q/max)*100}%,transparent 0)`}}>
      <span style={{color:red?'#f44336':'#4caf50'}}>{p.toFixed(1)}</span>
      <span>{q}</span>
    </div>;
  return <div className="card" style={{maxWidth:200}}>
    <h4>Order Book</h4>
    {asks.map(o=><Row key={'a'+o[0]} p={o[0]} q={o[1]} red/>)}
    <hr/>
    {bids.map(o=><Row key={'b'+o[0]} p={o[0]} q={o[1]}/>)}
  </div>;
}