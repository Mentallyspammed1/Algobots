import { TradingData } from '@/lib/types';
export function LogViewer({ logs }:{ logs: TradingData['logs'] }) {
  return (
    <div style={{background:'#0f1115',border:'1px solid #1c1f2a',borderRadius:8,padding:12, maxHeight:240, overflow:'auto'}}>
      <div style={{color:'#8aa0b4'}}>Logs</div>
      {logs.slice().reverse().map((l,i)=>( 
        <div key={i} style={{fontFamily:'ui-monospace, SFMono-Regular', fontSize:12, color: l.level==='ERROR'?'#ff5252': l.level==='WARNING'?'#ffb74d':'#9aa6b2'}}>
          [{new Date(l.timestamp).toLocaleTimeString()}] [{l.level}] {l.message}
        </div>
      ))}
    </div>
  );
}