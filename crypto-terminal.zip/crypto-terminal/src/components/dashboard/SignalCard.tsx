import { Signal } from '@/lib/types';
export function SignalCard({ signal }:{ signal: Signal }) {
  const color = signal.value==='BUY'?'#19c37d': signal.value==='SELL'?'#ff5252':'#8aa0b4';
  return (
    <div style={{background:'#0f1115',border:'1px solid #1c1f2a',borderRadius:8,padding:12}}>
      <div style={{color:'#8aa0b4'}}>Signal</div>
      <div style={{fontSize:36,fontWeight:800, color}}>{signal.value}</div>
      <div style={{color:'#8aa0b4'}}>Score: {typeof signal.score==='number' ? signal.score.toFixed(2) : signal.score}</div>
    </div>
  );
}