export function MarketDataCard({ symbol, price }:{symbol:string; price:string}) {
  return (
    <div style={{background:'#0f1115',border:'1px solid #1c1f2a',borderRadius:8,padding:12}}>
      <div style={{color:'#8aa0b4'}}>Market</div>
      <div style={{fontSize:20, fontWeight:600}}>{symbol}</div>
      <div style={{fontSize:28, fontWeight:700}}>${price}</div>
    </div>
  );
}