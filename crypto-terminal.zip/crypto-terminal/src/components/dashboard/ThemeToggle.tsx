'use client';
import { useEffect, useState } from 'react';

export function ThemeToggle() {
  const [dark, setDark] = useState(true);
  useEffect(() => { document.body.style.background = dark ? '#0b0b0d' : '#f4f6fa'; document.body.style.color = dark ? '#eaeaea' : '#111'; }, [dark]);
  return (
    <button onClick={()=>setDark(d=>!d)} title="Toggle theme">{dark ? '🌙' : '☀️'}</button>
  );
}