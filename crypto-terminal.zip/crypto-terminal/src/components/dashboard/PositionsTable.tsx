import { PositionRow } from '@/lib/types';
export function PositionsTable({ positions }:{ positions: PositionRow[] }) {
  return (
    <div style={{background:'#0f1115',border:'1px solid #1c1f2a',borderRadius:8,padding:12}}>
      <div style={{color:'#8aa0b4'}}>Open Positions</div>
      <table style={{width:'100%', borderCollapse:'collapse'}}>
        <thead><tr><th>Side</th><th>Entry</th><th>Qty</th><th>Lev</th><th>uPnL</th></tr></thead>
        <tbody>
          {positions.length? positions.map((p,i)=>( 
            <tr key={i}>
              <td>{p.side}</td><td>{p.entry_price}</td><td>{p.qty}</td><td>{p.leverage}x</td>
              <td style={{color: Number(p.pnl)>=0?'#19c37d':'#ff5252'}}>{Number(p.pnl).toFixed(2)}</td>
            </tr>
          )) : <tr><td colSpan={5} style={{textAlign:'center', color:'#8aa0b4'}}>No open positions</td></tr>}
        </tbody>
      </table>
    </div>
  );
}