'use client';
import Link from 'next/link';
import { ThemeToggle } from './ThemeToggle';

export function DashboardHeader({
  status, isConnected, onControl, settings, onExport
}: {
  status: string; isConnected: boolean; onControl: (a: 'start'|'stop') => void;
  settings?: any; onExport: ()=>void;
}) {
  const running = status === 'Running';
  return (
    <header style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'12px 16px',borderBottom:'1px solid #202028'}}>
      <div style={{display:'flex', alignItems:'center', gap:12}}>
        <h1 style={{margin:0,fontSize:18,color:'#4db6ff'}}>Bybit Trading App</h1>
        {settings?.armedLive ? <span style={{fontSize:12,color:'#19c37d'}}>LIVE ARMED</span> : <span style={{fontSize:12,color:'#8aa0b4'}}>SIM</span>}
      </div>
      <div style={{display:'flex',gap:10,alignItems:'center'}}>
        <button onClick={()=>onControl('start')} disabled={running || !isConnected}>Start</button>
        <button onClick={()=>onControl('stop')} disabled={!running || !isConnected}>Stop</button>
        <button onClick={onExport}>Export CSV</button>
        <Link href="/history">History</Link>
        <ThemeToggle />
        <span style={{display:'inline-flex',alignItems:'center',gap:6}}>
          <span>Status: {status}</span>
          <span style={{width:10,height:10,borderRadius:999, background:isConnected?'#19c37d':'#ff5252'}}/>
        </span>
      </div>
    </header>
  );
}