export function AccountBalanceCard({ equity, available }:{equity:string; available:string}) {
  return (
    <div style={{background:'#0f1115',border:'1px solid #1c1f2a',borderRadius:8,padding:12}}>
      <div style={{color:'#8aa0b4'}}>Account</div>
      <div>Total Equity: ${Number(equity||0).toLocaleString()}</div>
      <div>Available: ${Number(available||0).toLocaleString()}</div>
    </div>
  );
}