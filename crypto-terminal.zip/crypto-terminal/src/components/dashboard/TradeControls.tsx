'use client';
import { useState } from 'react';
import { BotSettings } from '@/lib/types';

export function TradeControls({
  settings: initialSettings, onUpdate
}: {
  settings: BotSettings; onUpdate: (p: Partial<BotSettings>) => void
}) {
  const [form, setForm] = useState(initialSettings);

  // Update form state when initialSettings change (e.g., from WS updates)
  useEffect(() => {
    setForm(initialSettings);
  }, [initialSettings]);

  const onChange = (k: keyof BotSettings) => (e: any) => {
    const v = typeof form[k] === 'number' ? Number(e.target.value) : (e.target.type==='checkbox'? e.target.checked : e.target.value);
    setForm({ ...form, [k]: v as any });
  };

  return (
    <div style={{background:'#0f1115',border:'1px solid #1c1f2a',borderRadius:8,padding:12}}>
      <div style={{color:'#8aa0b4'}}>Settings</div>
      <div style={{display:'grid', gridTemplateColumns:'repeat(2, 1fr)', gap:8}}>
        <label>Symbol <input value={form.symbol} onChange={onChange('symbol')} /></label>
        <label>Timeframe <select value={form.timeframe} onChange={onChange('timeframe')}>
          {['1','3','5','15','60','240','D'].map(t=> <option key={t} value={t}>{t}</option>)}
        </select></label>
        <label>Strategy <select value={form.strategy} onChange={onChange('strategy')}>
          <option value="RSI">RSI</option>
          <option value="MACD_CROSS">MACD Cross</option>
        </select></label>
        <label>Risk % <input type="number" step="0.1" value={form.riskPercentage} onChange={onChange('riskPercentage')} /></label>
        <label>RSI Period <input type="number" value={form.rsiPeriod} onChange={onChange('rsiPeriod')} /></label>
        <label>Overbought <input type="number" value={form.rsiOverbought} onChange={onChange('rsiOverbought')} /></label>
        <label>Oversold <input type="number" value={form.rsiOversold} onChange={onChange('rsiOversold')} /></label>
        <label>Partial Close % <input type="number" value={form.partialClosePct} onChange={onChange('partialClosePct')} /></label>
        <label style={{display:'flex', gap:6, alignItems:'center'}}><input type="checkbox" checked={form.armedLive} onChange={onChange('armedLive')} /> Armed Live</label>
      </div>
      <button style={{marginTop:8}} onClick={()=>onUpdate(form)}>Apply</button>
    </div>
  );
}