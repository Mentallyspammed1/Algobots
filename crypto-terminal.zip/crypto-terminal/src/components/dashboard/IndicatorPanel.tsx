export function IndicatorPanel({ indicators }:{ indicators: Record<string,string>}) {
  return (
    <div style={{background:'#0f1115',border:'1px solid #1c1f2a',borderRadius:8,padding:12}}>
      <div style={{color:'#8aa0b4'}}>Indicators</div>
      <ul style={{listStyle:'none', padding:0, margin:0}}>
        {Object.entries(indicators).map(([k,v]) => (
          <li key={k} style={{display:'flex', justifyContent:'space-between', padding:'4px 0'}}>
            <span>{k}</span><strong>{v}</strong>
          </li>
        ))}
      </ul>
    </div>
  );
}