'use client';
import { useEffect, useRef } from 'react';
import { createChart, IChartApi, ISeriesApi, UTCTimestamp } from 'lightweight-charts';
import type { ClosedTrade } from '@/lib/types';

export function ChartCard({ symbol, klines, lastPrice, trades }:{ 
  symbol:string; klines: Array<[string,string,string,string,string,string]>; lastPrice:number; trades: ClosedTrade[];
}) {
  const ref = useRef<HTMLDivElement | null>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);

  useEffect(()=>{
    if (!ref.current) return;
    chartRef.current = createChart(ref.current, {
      width: ref.current.clientWidth, height: 380,
      layout:{ background:{ type:'Solid', color:'#101014' }, textColor:'#ccc' },
      grid:{ horzLines:{ color:'#222' }, vertLines:{ color:'#222' } }
    });
    seriesRef.current = chartRef.current.addCandlestickSeries({
      upColor:'#26a69a', downColor:'#ef5350', wickUpColor:'#26a69a', wickDownColor:'#ef5350',
      borderUpColor:'#26a69a', borderDownColor:'#ef5350'
    });
    const data = klines.slice().reverse().map(k => ({
      time: (Number(k[0]) / 1000) as UTCTimestamp,
      open: Number(k[1]), high: Number(k[2]), low: Number(k[3]), close: Number(k[4])
    }));
    seriesRef.current.setData(data);
    const onResize = () => chartRef.current?.resize(ref.current!.clientWidth, 380);
    window.addEventListener('resize', onResize);
    return () => { window.removeEventListener('resize', onResize); chartRef.current?.remove(); };
  }, [symbol, klines]);

  useEffect(()=>{
    if (!seriesRef.current || klines.length===0) return;
    const k = klines[0];
    seriesRef.current.update({
      time: (Number(k[0]) / 1000) as UTCTimestamp,
      open: Number(k[1]), high: Math.max(Number(k[2]), lastPrice),
      low: Math.min(Number(k[3]), lastPrice), close: lastPrice
    });
  }, [lastPrice, klines]);

  useEffect(()=>{
    if (!seriesRef.current) return;
    const markers = trades.map(t => ({
      time: (new Date(t.exitTime).getTime()/1000) as UTCTimestamp,
      position: 'aboveBar' as const,
      color: t.pnl>=0?'#19c37d':'#ff5252',
      shape: 'arrowDown' as const,
      text: `${t.side} ${t.pnl>=0?'+':''}${t.pnl.toFixed(0)}`
    }));
    seriesRef.current.setMarkers(markers);
  }, [trades]);

  return (
    <div style={{gridColumn:'span 4', background:'#0f1115', border:'1px solid #1c1f2a', borderRadius:8, padding:12}}>
      <div style={{marginBottom:8, color:'#8aa0b4'}}>{symbol} Price</div>
      <div ref={ref} />
    </div>
  );
}