import React, { useState, useEffect } from 'react';
import { BybitClient } from '../lib/bybitClient.ts';

interface PositionRow {
  side: 'Buy' | 'Sell';
  entry_price: string;
  qty: string;
  status: 'OPEN';
  pnl: string;
  leverage: string;
}

export default function PositionsCard({ client }: { client: BybitClient }) {
  const [positions, setPositions] = useState<PositionRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPositions = async () => {
      try {
        const result = await client.getPositions();
        if (result && result.length > 0) {
          // Assuming 'linear' category and relevant fields are present
          const openPositions: PositionRow[] = result.map((p: any) => ({
            side: p.side,
            entry_price: p.avgPrice,
            qty: p.size,
            status: p.positionStatus, // Assuming 'OPEN' or similar
            pnl: p.unrealisedPnl,
            leverage: p.leverage,
          })).filter((p: any) => parseFloat(p.qty) > 0); // Filter for open positions
          setPositions(openPositions);
        } else {
          setPositions([]); // No open positions
        }
      } catch (err: any) {
        setError(`Failed to fetch positions: ${err.message || 'Unknown error'}`);
        console.error('Failed to fetch positions:', err);
      }
    };

    fetchPositions();
    const interval = setInterval(fetchPositions, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, [client]);

  return (
    <div className="card">
      <h4>Open Positions</h4>
      {error && <div style={{ color: 'red' }}>Error: {error}</div>}
      {positions.length > 0 ? (
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <th>Side</th>
              <th>Entry</th>
              <th>Qty</th>
              <th>Lev</th>
              <th>uPnL</th>
            </tr>
          </thead>
          <tbody>
            {positions.map((p, i) => (
              <tr key={i}>
                <td style={{ color: p.side === 'Buy' ? '#4caf50' : '#f44336' }}>{p.side}</td>
                <td>{Number(p.entry_price).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td>{Number(p.qty).toLocaleString()}</td>
                <td>{p.leverage}x</td>
                <td style={{ color: Number(p.pnl) >= 0 ? '#4caf50' : '#f44336' }}>{Number(p.pnl).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <div>No open positions.</div>
      )}
    </div>
  );
}