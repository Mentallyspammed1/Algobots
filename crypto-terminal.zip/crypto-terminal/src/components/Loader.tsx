import React from 'react';
export default function Loader({ height }: { height?: number }) {
  return <div className="skeleton" style={{ height: height || '100%', width: '100%' }}></div>;
}