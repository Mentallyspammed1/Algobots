import React from 'react';

export default function PerformanceCard() {
  return (
    <div className="card">
      <h4>Performance</h4>
      <div>(Future: Display historical performance metrics here)</div>
      <p>Trade history and PnL tracking would be implemented here.</p>
    </div>
  );
}