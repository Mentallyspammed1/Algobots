import React, { useEffect, useRef, useState } from 'react';
import { createChart, IChartApi, ISeriesApi, UTCTimestamp } from 'lightweight-charts';
import { BybitClient } from '../lib/bybitClient.ts';

export default function PriceChart({ client, symbol }: { client: BybitClient; symbol: string }) {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candlestickSeriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);
  const [klines, setKlines] = useState<any[]>([]);
  const [currentPrice, setCurrentPrice] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Initialize chart and fetch historical data
  useEffect(() => {
    if (!chartContainerRef.current) return;

    // Dispose of previous chart instance if it exists
    if (chartRef.current) {
      chartRef.current.remove();
    }

    chartRef.current = createChart(chartContainerRef.current, {
      width: chartContainerRef.current.clientWidth,
      height: 320, // Matches the fallback loader height
      layout: {
        background: { type: 'Solid', color: '#101014' },
        textColor: '#ccc',
      },
      grid: {
        vertLines: { color: '#222' },
        horzLines: { color: '#222' },
      },
      timeScale: {
        timeVisible: true,
        secondsVisible: false,
      },
    });

    candlestickSeriesRef.current = chartRef.current.addCandlestickSeries({
      upColor: '#26a69a',
      downColor: '#ef5350',
      wickUpColor: '#26a69a',
      wickDownColor: '#ef5350',
      borderUpColor: '#26a69a',
      borderDownColor: '#ef5350',
    });

    const fetchKlines = async () => {
      try {
        // getKlines returns list in reverse chronological order (newest first)
        const fetchedKlines = await client.getKlines(symbol, '1', 200); // 1-minute interval, 200 candles
        if (fetchedKlines && fetchedKlines.length > 0) {
          // Lightweight Charts expects chronological order (oldest first)
          const formattedKlines = fetchedKlines.map((k: any) => ({
            time: (parseInt(k[0]) / 1000) as UTCTimestamp, // Timestamp in seconds
            open: parseFloat(k[1]),
            high: parseFloat(k[2]),
            low: parseFloat(k[3]),
            close: parseFloat(k[4]),
          })).reverse(); // Reverse to chronological order

          candlestickSeriesRef.current?.setData(formattedKlines);
          setKlines(fetchedKlines); // Store original for updates
          setCurrentPrice(parseFloat(fetchedKlines[0][4])); // Last close price
        } else {
          setError('No kline data received.');
        }
      } catch (err: any) {
        setError(`Failed to fetch klines: ${err.message || 'Unknown error'}`);
        console.error('Failed to fetch klines:', err);
      }
    };

    fetchKlines();

    // Handle chart resizing
    const handleResize = () => {
      if (chartContainerRef.current && chartRef.current) {
        chartRef.current.resize(chartContainerRef.current.clientWidth, 320);
      }
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      chartRef.current?.remove(); // Clean up chart instance
    };
  }, [client, symbol]);

  // Subscribe to real-time trade updates for current price
  useEffect(() => {
    const handleTrade = (trade: { p: number; q: number; ts: number; s: 'Buy' | 'Sell' }) => {
      setCurrentPrice(trade.p);
      // Update the last candle with the new price
      if (candlestickSeriesRef.current && klines.length > 0) {
        const lastKline = klines[0]; // Newest kline from fetched data
        candlestickSeriesRef.current.update({
          time: (parseInt(lastKline[0]) / 1000) as UTCTimestamp,
          open: parseFloat(lastKline[1]),
          high: Math.max(parseFloat(lastKline[2]), trade.p),
          low: Math.min(parseFloat(lastKline[3]), trade.p),
          close: trade.p,
        });
      }
    };

    client.onTrade(handleTrade);

    return () => {
      // No direct unsubscribe method for onTrade, assuming client handles internal cleanup
    };
  }, [client, klines]);


  return (
    <div className="card">
      <h4>Price Chart for {symbol}</h4>
      {error && <div style={{ color: 'red' }}>Error: {error}</div>}
      <div ref={chartContainerRef} style={{ position: 'relative', height: '320px' }}>
        {currentPrice !== null && (
          <div style={{
            position: 'absolute',
            top: '10px',
            left: '10px',
            zIndex: 10,
            background: 'rgba(0,0,0,0.5)',
            padding: '5px 10px',
            borderRadius: '5px',
            color: '#fff',
            fontSize: '1.2em'
          }}>
            {symbol}: {currentPrice.toFixed(2)}
          </div>
        )}
      </div>
    </div>
  );
}