import React,{useEffect,useRef} from 'react';
import { BybitClient } from '../lib/bybitClient.ts';

export default function TradesTape({client}:{client:BybitClient}){
  const box=useRef<HTMLDivElement>(null);
  useEffect(()=>client.onTrade(t=>{
    const div=document.createElement('div');
    div.textContent=`${t.s==='Buy'?'⬆':'⬇'} ${t.p}  (${t.q})`;
    div.style.color=t.s==='Buy'?'#4caf50':'#f44336';
    box.current?.prepend(div);
    if(box.current!.childElementCount>40) box.current!.removeChild(box.current!.lastChild!);
  }),[client]);
  return <div ref={box} className="card" style={{height:150,overflow:'auto'}}>
    <h4>Trades</h4>
  </div>;
}