import React, { useState, useEffect } from 'react';
import { BybitClient } from '../lib/bybitClient.ts';

interface AccountBalance {
  equity: string;
  available_balance: string;
}

export default function BalanceCard({ client }: { client: BybitClient }) {
  const [balance, setBalance] = useState<AccountBalance | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchBalance = async () => {
      try {
        const result = await client.getBalance();
        if (result && result.list && result.list.length > 0) {
          const unifiedAccount = result.list.find((acc: any) => acc.accountType === 'UNIFIED');
          if (unifiedAccount) {
            setBalance({
              equity: unifiedAccount.totalEquity,
              available_balance: unifiedAccount.totalAvailableBalance,
            });
          } else {
            setError('Unified account balance not found.');
          }
        } else {
          setError('No balance data received.');
        }
      } catch (err: any) {
        setError(`Failed to fetch balance: ${err.message || 'Unknown error'}`);
        console.error('Failed to fetch balance:', err);
      }
    };

    fetchBalance();
    const interval = setInterval(fetchBalance, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, [client]);

  return (
    <div className="card">
      <h4>Account Balance</h4>
      {error && <div style={{ color: 'red' }}>Error: {error}</div>}
      {balance ? (
        <>
          <div>Total Equity: ${Number(balance.equity).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
          <div>Available Balance: ${Number(balance.available_balance).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
        </>
      ) : (
        <div>Loading balance...</div>
      )}
    </div>
  );
}