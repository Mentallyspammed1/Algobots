import React, { useState, useEffect } from 'react';
import { BybitClient } from '../lib/bybitClient.ts';
import { saveSetting, loadSetting } from '../lib/storage.ts'; // Import saveSetting and loadSetting

// Utility for i18n lookup (copied from app.tsx for self-containment)
function t(key: string): string {
  const lang = localStorage.getItem('lang') || 'en';
  const json = document.getElementById(`i18n-${lang}`)?.textContent;
  try {
    return JSON.parse(json ?? '{}')[key] ?? key;
  } catch {
    return key;
  }
}

export default function SettingsModal({ client, close }: { client: BybitClient; close: () => void; }) {
  const [currentTheme, setCurrentTheme] = useState<string>('dark'); // Default to dark
  const [currentLang, setCurrentLang] = useState<string>('en'); // Default to English

  useEffect(() => {
    loadSetting('theme').then(t => { if (t) setCurrentTheme(t); });
    setCurrentLang(localStorage.getItem('lang') || 'en');
  }, []);

  const toggleTheme = async () => {
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    setCurrentTheme(newTheme);
    document.body.className = newTheme;
    await saveSetting('theme', newTheme);
  };

  const handleLanguageChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newLang = e.target.value;
    setCurrentLang(newLang);
    localStorage.setItem('lang', newLang);
    alert('Language changed. Please refresh the page to apply changes.');
  };

  return (
    <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.7)', display: 'grid', placeContent: 'center', zIndex: 1000 }}>
      <div className="card" style={{ minWidth: 300, padding: '20px' }}>
        <h4>{t('Settings')}</h4> {/* Using t() for Settings title */}
        <div style={{ marginBottom: '15px' }}>
          <label style={{ display: 'block', marginBottom: '5px' }}>Theme:</label>
          <button onClick={toggleTheme}>
            {currentTheme === 'dark' ? '🌙 Dark' : '☀️ Light'}
          </button>
        </div>
        <div style={{ marginBottom: '15px' }}>
          <label style={{ display: 'block', marginBottom: '5px' }}>Language:</label>
          <select value={currentLang} onChange={handleLanguageChange} style={{ padding: '5px' }}>
            <option value="en">English</option>
            <option value="es">Español</option>
          </select>
        </div>
        <button onClick={close} style={{ marginTop: '20px', width: '100%' }}>Close</button>
      </div>
    </div>
  );
}