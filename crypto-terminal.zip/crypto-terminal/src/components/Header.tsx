import React from 'react';
import { BybitClient } from '../lib/bybitClient.ts';

export default function Header(
  {client,symbol,dark,toggleDark}:
  {client:BybitClient,symbol:string,dark:boolean,toggleDark:()=>void}){
  return (
    <header style={{display:'flex',gap:8,padding:8,alignItems:'center'}}>
      <strong>{symbol}</strong>
      <span style={{marginLeft:'auto',fontSize:12}}>
        WS: <b style={{color:client.latency<150?'#4caf50':client.latency<400?'#ffb300':'#f44336'}}>
              {client.latency||'…'} ms</b> · RL <b>{client.rate60}/60</b>
      </span>
      <button onClick={toggleDark}>{dark?'☀️':'🌙'}</button>
    </header>
  );
}