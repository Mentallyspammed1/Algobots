# Dashboard User Manual

Welcome to your Bybit Trading Dashboard. This guide explains how to use its features.

## 1. Initial Setup

### API Keys

Before you can use the dashboard, you must configure your Bybit API keys.

1.  Open the `.env.js` file in the project's root directory.
2.  Enter your API key and secret. **It is highly recommended to start with TESTNET keys.**
3.  Ensure `TESTNET: true` is set. To use real funds, change this to `TESTNET: false`.

### Launching the App

The application must be run from a local web server.

1.  Open a terminal in the project's root directory.
2.  Run the command: `python -m http.server 8000`
3.  Open your browser and go to `http://localhost:8000`.

## 2. Dashboard Interface

The dashboard is composed of several widgets:

- **Header:** Shows the current symbol, WebSocket latency, and a theme toggle button.
- **Symbol Selector:** A dropdown menu below the header to switch between different trading pairs (e.g., BTCUSDT, ETHUSDT).
- **Settings Button:** Opens the settings modal.
- **Price Chart:** Displays the price action for the selected symbol. *(Currently a placeholder).*
- **Order Book:** Shows a real-time list of buy (bids) and sell (asks) orders.
- **Trades Tape:** A real-time feed of the latest public trades.
- **Balance Card:** Displays your account equity. *(Currently a placeholder).*
- **Positions Card:** Shows your open positions. *(Currently a placeholder).*
- **Trade Controls:** Allows you to place new orders.
- **Performance Card:** Shows historical performance. *(Currently a placeholder).*

## 3. How to Use

### Change Trading Symbol

Use the dropdown menu located just below the header to select a new symbol. The dashboard will update to show data for the new pair.

### Place an Order

1.  Go to the **Trade Controls** card.
2.  Click the "Buy" or "Sell" button for a market order.
3.  Click the "Buy Limit" or "Sell Limit" button for a limit order.
4.  A prompt will appear asking for the quantity. Enter the desired amount and confirm.
5.  For limit orders, a second prompt will ask for the price.

### Change Theme

- Click the ☀️ / 🌙 icon in the header.
- Alternatively, press the `d` key on your keyboard.

### Open Settings

- Click the "settings" button below the header.
- Alternatively, press `Ctrl + S` on your keyboard.

## 4. Troubleshooting

- **Data is not loading:**
    1.  Ensure your API key and secret in `.env.js` are correct and have the right permissions on the Bybit website.
    2.  Check the browser's developer console (usually F12) for any error messages, especially related to network requests or WebSocket connections.

- **Application does not load:**
    - Make sure you are running the app from a web server (`http://localhost:8000`) and not by opening the `index.html` file directly.
