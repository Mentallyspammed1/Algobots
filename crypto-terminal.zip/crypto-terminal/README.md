# Bybit Trading Dashboard

A lightweight, client-only trading dashboard for the Bybit exchange, built with TypeScript and React. This application runs directly in the browser without any build step or server-side dependency.

## Features

- **Real-Time Data:** Live order book and trade tape powered by Bybit WebSockets.
- **Interactive Charting:** A lazy-loaded, responsive price chart. *(Note: Currently a placeholder).*
- **Account Management:** View your balance and open positions. *(Note: Currently placeholders).*
- **Direct Trading:** Place Market and Limit orders directly from the dashboard.
- **Secure Storage:** API keys and user settings are saved to `localStorage` using AES-GCM encryption.
- **Customizable UI:**
    - Dark / Light theme support (toggle with the 'd' key).
    - Responsive grid layout that adapts to screen size.
- **i18n Ready:** Includes a simple internationalization scaffold for UI text (EN/ES).
- **Zero Build:** Runs natively in modern browsers using ES Modules and Import Maps.

## Tech Stack

- **TypeScript**
- **React 19** (via browser ESM import)
- **Axios** (for REST API calls)
- **Lightweight Charts** (for price chart)
- **No Bundler:** The project uses a `<script type="importmap">` in `index.html` to manage dependencies, eliminating the need for Webpack, Vite, or similar tools.

## Getting Started

### 1. Configure Environment

- Rename `.env.js.example` to `.env.js` (if applicable) or edit `.env.js`.
- Open `.env.js` and enter your Bybit **TESTNET** API key and secret.
- It is strongly recommended to use testnet keys first. To switch to the mainnet, change `TESTNET: true` to `TESTNET: false`.

```javascript
// .env.js
export const ENV = {
  BYBIT_API_KEY:    'YOUR_TESTNET_KEY',
  BYBIT_API_SECRET: 'YOUR_TESTNET_SECRET',
  TESTNET: true,
  // ... other settings
};
```

### 2. Run the Application

This application must be served by a static HTTP server. It will not work if you open `index.html` directly from the filesystem (`file://...`).

A simple way to do this is with Python's built-in server:

```bash
# Make sure you are in the project's root directory
python -m http.server 8000
```

Once the server is running, open your web browser and navigate to:

**http://localhost:8000**

## Project Structure

```
/
├─ index.html            # Main HTML file with import maps
├─ .env.js               # Environment configuration (API keys)
├─ manifest.json         # PWA manifest (placeholder)
├─ service-worker.js     # PWA service worker (placeholder)
└─ src/
   ├─ index.tsx          # React entry point
   ├─ app.tsx            # Main application component
   ├─ lib/               # Core logic (Bybit client, storage, etc.)
   └─ components/        # Reusable React components
```