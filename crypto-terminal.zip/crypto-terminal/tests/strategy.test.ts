import { describe, it, expect } from 'vitest';
import { rsiStrategy } from '../server/strategies/rsi';
import { macdCrossStrategy } from '../server/strategies/macd-cross';

describe('strategies', () => {
  it('RSI strategy emits BUY when oversold', () => {
    const closes = Array(50).fill(100).map((v,i)=> v - i*0.5);
    const res = rsiStrategy.run({
      closes, highs: closes, lows: closes, open: closes, price: closes.at(-1)!,
      settings: { rsiPeriod: 14, rsiOverbought: 70, rsiOversold: 30, macdFast: 12, macdSlow: 26, macdSignal: 9 }
    });
    expect(['BUY','HOLD']).toContain(res.signal);
  });

  it('MACD cross compiles and returns result', () => {
    const closes = Array.from({length:200}, (_,i)=> 100 + Math.sin(i/10)*2);
    const res = macdCrossStrategy.run({
      closes, highs: closes, lows: closes, open: closes, price: closes.at(-1)!,
      settings: { rsiPeriod:14, rsiOverbought:70, rsiOversold:30, macdFast:12, macdSlow:26, macdSignal:9 }
    });
    expect(['BUY','SELL','HOLD']).toContain(res.signal);
  });
});