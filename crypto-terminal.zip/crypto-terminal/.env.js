// NEVER commit real keys.
export const ENV = {
  BYBIT_API_KEY:    'YOUR_TESTNET_KEY',
  BYBIT_API_SECRET: 'YOUR_TESTNET_SECRET',
  TESTNET: true,                    // flip to false for main-net
  SYMBOLS: ['BTCUSDT','ETHUSDT'],
  GOOGLE_GENAI_API_KEY: 'YOUR_GEMINI_KEY',
  ENC_KEY: 'correct horse battery staple'  // AES-GCM key for localStorage
};